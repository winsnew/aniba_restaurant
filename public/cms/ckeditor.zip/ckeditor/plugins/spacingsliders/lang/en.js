CKEDITOR.plugins.setLang( 'spacingsliders', 'en', {
	title: 'Line and Letter Spacing',
	labels: {
		lineheight: 'Line Height',
		letterspacing: 'Letter Spacing'
	}
} );
