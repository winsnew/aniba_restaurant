CKEDITOR.plugins.setLang('spacingsliders', 'uk', {
    title: 'Міжрядковий та міжлітерний інтервал',
    labels: {
        lineheight: 'Міжрядковий інтервал',
        letterspacing: 'міжлітерний інтервал'
    }
});
